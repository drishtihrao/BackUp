
public class ThreeWheeler implements Vehicle{
	public void start() {
		System.out.println("Starting three wheeler");
	}

}
