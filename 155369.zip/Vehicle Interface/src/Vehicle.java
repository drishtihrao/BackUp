
interface Vehicle {
	void start();

}
