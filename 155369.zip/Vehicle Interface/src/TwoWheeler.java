
public class TwoWheeler implements Vehicle{
	public void start() {
		System.out.println("Starting two wheeler");
	}

}
