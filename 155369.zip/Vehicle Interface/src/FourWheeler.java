
public class FourWheeler implements Vehicle {
	public void start() {
		System.out.println("Starting four wheeler");
	}

}
