import java.time.LocalDate;
import java.time.Period;

public class Date1 {
	private int date, month, year;

	public Date1(int d, int m, int y) {
		this.date = d;
		this.month = m;
		this.year = y;
	}

	@Override
	public String toString() {
		return "Date " + this.date + " / " + this.month + " / " + this.year + "";
	}

	//to check if the entered date is smaller than the other date
	public boolean isSmaller(Date1 d) {
		boolean flag;
		if (this.year == d.year) {
			if (this.month == d.month) {
				if (this.date == d.date) {
					flag = true;
				} else if (this.date < d.date) {
					flag = false;
				} else {
					flag = true;
				}
			} else if (this.month < d.month) {
				flag = false;
			} else {
				flag = true;
			}
		} else if (this.year < d.year) {
			flag = false;
		} else {
			flag = true;
		}
		return flag;
	}

	public int[] diff(Date1 d) {
		int date[] = new int[3];
		LocalDate d1, d2;
		Period p;
		d1 = LocalDate.of(this.year, this.month, this.date);
		d2 = LocalDate.of(d.year, d.month, d.date);
		
		if (d1.getYear() == d2.getYear()) {
			if (d1.getMonth() == d2.getMonth()) {
				if (d1.getDayOfYear() == d2.getDayOfYear()) {
					p = Period.between(d1, d2);
				} 
				else if (d1.getDayOfYear() > d2.getDayOfYear()) {
					p = Period.between(d2, d1);
				} 
				else {
					p = Period.between(d1, d2);
				}
			} 
			else if (d1.getMonthValue() > d2.getMonthValue()) {
				p = Period.between(d2, d1);
			} else {
				p = Period.between(d1, d2);
			}
		}
		else if (d1.getYear() > d2.getYear()) {
			p = Period.between(d2, d1);
		} 
		else {
			p = Period.between(d1, d2);
		}
		
		date[2] = p.getYears();
		date[1] = p.getMonths();
		date[0] = p.getDays();
		return date;
	}

	public int[] age() {
		int date[] = new int[3];
		LocalDate d1, d2 = LocalDate.now();
		
		d1 = LocalDate.of(this.year, this.month, this.date);
		Period p = Period.between(d1, d2);
		date[2] = p.getYears();
		date[1] = p.getMonths();
		date[0] = p.getDays();
		return date;
	}

	public int getD() {
		return date;
	}

	public int getM() {
		return month;
	}

	public int getY() {
		return year;
	}
}