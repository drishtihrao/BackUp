//test class 
public class TestPerson {
	public static void main(String[] args) {
		Person dr = new Person("DR", 18, 12, 1996);
		Person kw = new Person("KW", 27, 9, 1989);
		dr.display();
		kw.display();
		kw.olderOne(dr);
	}
}