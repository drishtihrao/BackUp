//Test class for GenerateEmployeeID
public class TestGenerateEmpId {
	public static void main(String[] args) {
		
		//Creating Object
		GenerateEmpId employee = new GenerateEmpId();
		
		//Getting current employeeID
		int employeeID = employee.getEmployeeID();
		System.out.println(employeeID);
		
		//Getting next employeeID
		employeeID = GenerateEmpId.getNextEmployeeID();
		System.out.println(employeeID);
	}
}