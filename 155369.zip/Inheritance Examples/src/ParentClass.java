
class ParentClass {
	void display(String name) {
		System.out.println("Name is " + name);
	}
}
