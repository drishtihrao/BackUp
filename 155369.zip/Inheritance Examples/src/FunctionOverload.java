
public class FunctionOverload {
	public static void main(String[] args) {
		ChildClass child = new ChildClass();
		child.display(50);
		child.display("Drishti");
	}
}