
class ChildClass extends ParentClass {
	void display(int number) {
		System.out.println("Number is " + number);
	}
}

