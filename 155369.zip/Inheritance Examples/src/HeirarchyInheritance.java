
public class HeirarchyInheritance {
	public static void main(String[] args) {
		Hello n = new Hello();
		Ohh o = new Ohh();
	}
}