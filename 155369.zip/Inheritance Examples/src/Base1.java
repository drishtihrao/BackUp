//base class is the the parent class
class Base1{
//	Base1(){
//	System.out.println("default");
//	}
}

//sub class inherits from base class
//sub class has three constructors, each with different parameters
class Sub1 extends Base1 {
	int i,j;
	Sub1(){
		System.out.println("Default constructor");
	}

	Sub1(int i) {
		this.i = i;
		System.out.println("one parameter ctor with parameter " + i);
	}

	Sub1(int i, int j) {
		this.i = i;
		this.j = j;
		System.out.println("two parameter ctor with parameters " + i + "," + j);
	}
}