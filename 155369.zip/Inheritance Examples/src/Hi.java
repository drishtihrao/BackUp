//Hi is the parent class of hello and ohh, which gets called by default constructor
class Hi {
	Hi() {
			System.out.println("Hi");
		}
}