//hello is a child class of class Hi and hence it first implicitly calls the class hi and displays hi
class Hello extends Hi {
	Hello() {
			System.out.println("Hello");
	}
}