//inheritance of parameterised class
class Sub1Test {
	public static void main(String args[]) {
		Sub1 s = new Sub1();
		Sub1 t = new Sub1(5, 7);
	}
}