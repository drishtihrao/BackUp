//ohh is a child class of class Hi and hence it first implicitly calls the class hi and displays hi
class Ohh extends Hi {
	Ohh() {
			System.out.println("Ohh");
	}
}
