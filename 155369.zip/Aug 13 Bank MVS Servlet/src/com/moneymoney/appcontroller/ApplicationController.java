package com.moneymoney.appcontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.moneymoney.app.model.service.ServiceImpl;

@WebServlet("*.app")
public class ApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServiceImpl service = new ServiceImpl();

	public ApplicationController() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		HttpSession session = request.getSession();
		//RequestDispatcher dispatcher = new RequestDispatcher();
		
		System.out.println(action);
		switch (action) {
		case "/addnew.app":
			response.sendRedirect("addNewAccount.jsp");
			break;
		case "/withdraw.app":
			int accNo = Integer.parseInt(request.getParameter("accNo"));
			double amount = Double.parseDouble(request.getParameter("amount"));
			service.withdraw(accNo, amount);
			
			//response.sendRedirect("addNewAccount.jsp");
			
			break;
		case "/deposit.app":
			accNo = Integer.parseInt(request.getParameter("accNo"));
			amount = Double.parseDouble(request.getParameter("amount"));
			service.deposit(accNo, amount);
			//response.sendRedirect("addNewAccount.jsp");
			
			break;
		default:
			break;
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
