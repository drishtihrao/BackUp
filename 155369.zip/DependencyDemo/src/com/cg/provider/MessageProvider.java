package com.cg.provider;

public interface MessageProvider {
	public String getMessage();
}
