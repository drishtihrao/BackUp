//class C inherits from interface B
public class C implements B{
	//overriding the methods defined in parent interfaces
	public void disp1() {
		System.out.println("This is d1");
	}
	public void disp2() {
		System.out.println("This is d2");
	}
}


