//parent interface
interface A {
	//creating an abstract method
	abstract void disp1();

}
