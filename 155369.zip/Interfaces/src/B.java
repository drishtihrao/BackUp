//interface B is interface inherits by A
 interface B extends A {
	//creating an abstract method
		abstract void disp2();
}
