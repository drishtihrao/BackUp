
public class TestC {
	public static void main(String args[]) {
		C c = new C();
		c.disp1();
		c.disp2();

	}
}
