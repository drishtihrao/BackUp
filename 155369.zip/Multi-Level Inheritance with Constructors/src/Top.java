//parent node with a constructor with an integer parameter
public class Top {
	int tvar;
	public Top(int i) {
		this.tvar = i;
		System.out.println("Parent");
	}
	
}
