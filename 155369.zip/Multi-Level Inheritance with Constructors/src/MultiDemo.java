//main method to test the multi level heirarchy using constructors
public class MultiDemo {

	public static void main(String[] args) {
		Leaf leaf = new Leaf(12);
	}

}
