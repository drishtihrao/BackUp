package com.cg.onlinebookstore.cart;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.onlinebookstore.pojo.Book;

public class CartList {
	Book book = new Book();
	int cartCount =0;
	static Map<String, Book> cartList = new HashMap<>();
	

	public void addToCart(Book book) {
		
		++cartCount;
		System.out.println("cart count is" + cartCount);
//		for(Book books: cartList.values()) {
//			if(books.getBookName() == book.getBookName()) {
//				books.setBookCount(books.getBookCount() + 1);
//				break;
//			}
//		}

		boolean flag = true;
		for (Book books : cartList.values()) {
			
			if (books.getBookName().equals(book.getBookName())) {
				System.out.println("***********");
				System.out.println(books);
				books.setBookCount(books.getBookCount() + 1);
				flag = false;
				break;
			}
		}

		if (flag) {
			book.setBookCount(1);
			cartList.put(book.getBookName(), book);

		}

	}

	public void deleteFromCart(Book book) {
		cartCount--;
		for (Book books : cartList.values()) {
			if (books.getBookName().equals(book.getBookName())) {
				if (books.getBookCount() == 1) {
					cartList.remove(book.getBookName());
				}
				if (books.getBookCount() > 1) {
					books.setBookCount(books.getBookCount() - 1);
				}

				break;
			}
		}
	}

	public int getCartCount() {
		return cartCount;
	}

	public Collection<Book> displayCartList() {
		return cartList.values();
	}
}
