package com.cg.onlinebookstore.service;

import java.util.Collection;

import com.cg.onlinebookstore.pojo.Book;

public interface StoreService {
	
	void addToCart(Book book);
	
	void deleteFromCart(Book book);
	
	int getCartCount();

	Collection<Book> displayAllBooks();
	
	Collection<Book> displayCartList();

}