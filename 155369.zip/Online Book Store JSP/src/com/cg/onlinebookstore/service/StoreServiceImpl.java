package com.cg.onlinebookstore.service;

import java.util.Collection;

import com.cg.onlinebookstore.cart.CartList;
import com.cg.onlinebookstore.dao.StoreDAOImpl;
import com.cg.onlinebookstore.pojo.Book;

public class StoreServiceImpl implements StoreService {
	StoreDAOImpl dao = new StoreDAOImpl();
	CartList cartList = new CartList();

	@Override
	public Collection<Book> displayAllBooks() {
		return dao.displayAllBooks();
	}
	
	public void addToCart(Book book) {
		cartList.addToCart(book);
	}
	
	public Collection<Book> displayCartList(){
		return cartList.displayCartList();
	}

	public void deleteFromCart(Book book) {
		cartList.deleteFromCart(book);
	}
	
	public int getCartCount() {
		return cartList.getCartCount();
	}
}
