package com.cg.onlinebookstore.dao;

import java.util.Collection;

import com.cg.onlinebookstore.pojo.Book;

public interface StoreDAO {

	void homePageList();

	Collection<Book> displayAllBooks();

}