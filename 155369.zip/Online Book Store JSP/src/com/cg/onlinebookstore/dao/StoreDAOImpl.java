package com.cg.onlinebookstore.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.onlinebookstore.pojo.Book;

public class StoreDAOImpl implements StoreDAO {
	static Map<String, Book> bookList = new HashMap<>();

	@Override
	public void homePageList() {
		Book hp = new Book("Hp", "JK", "Magical", 700, 0);
		Book fh = new Book("Fountainhead", "Ayn Rand", "Arch", 500, 0);
		Book al = new Book("Alchemist", "Paulo Coleho", "Phylosophical", 150, 0);
		Book sh = new Book("Sherlock Holmes", "Conan Doyle", "Mystery", 650, 0);
		Book got = new Book("GOT", "M", "Murder", 1700, 0);

		bookList.put(hp.getBookName(), hp);
		bookList.put(fh.getBookName(), fh);
		bookList.put(al.getBookName(), al);
		bookList.put(sh.getBookName(), sh);
		bookList.put(got.getBookName(), got);

	}

	@Override
	public Collection<Book> displayAllBooks() {
		return bookList.values();
	}

}
