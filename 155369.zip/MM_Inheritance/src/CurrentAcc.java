//Class CurrentAcc inherits variables and methods from class BankAcc

abstract class CurrentAcc extends BankAcc {
	private final float creditLimit;
	public abstract void withdraw(float amount);

	
	public CurrentAcc(int accNo, String accNm,float accBal, float creditLimit) {
		super(accNo, accNm, accBal);
		this.creditLimit = creditLimit;
	}

	public float getCreditLimit() {
		return creditLimit;
	}


	@Override
	public String toString() {
		return "CurrentAcc creditLimit =" + creditLimit + "," + super.toString() + ".";
	}
	
	
	

}