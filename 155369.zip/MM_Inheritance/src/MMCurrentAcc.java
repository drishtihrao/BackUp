//this class overrides the methods defined in Parent class CurrentAcc
public class MMCurrentAcc extends CurrentAcc{
	public MMCurrentAcc(int accNo, String accNm,float accBal, float creditLimit) {
		super(accNo, accNm, accBal, creditLimit);
		
	}
	
	public void withdraw(float amount) {
			if(((getAccBal()+getCreditLimit()) - amount) >= 0) {
			setAccBal(getAccBal()+getCreditLimit() - amount);
			}
			else {
				System.out.println("Transaction failed");
			}
		}
	@Override
	public String toString() {
		return "MMCurrentAcc =" + super.toString() + ".";
	}
	
	
	
	

}
