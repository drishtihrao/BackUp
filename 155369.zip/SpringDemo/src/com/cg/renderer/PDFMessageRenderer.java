package com.cg.renderer;

import javax.naming.Context;

import com.cg.company.Organization;
import com.cg.provider.MessageProvider;

public class PDFMessageRenderer implements MessageRenderer {
	private MessageProvider provider;
	private int p;

	public PDFMessageRenderer() {

	}

	public PDFMessageRenderer(MessageProvider provider) {
		this.provider = provider;
	}
	
	public void setNamespace(int p) {
		
		this.p =p;
		System.out.println("namespace" + p);
	}

	@Override
	public void render() {
		System.out.println(provider.getMessage() + "on PDF");
	}

	/*
	 * @Override public void setMessageProvider(MessageProvider provider) {
	 * this.provider = provider; }
	 */
	
	
}