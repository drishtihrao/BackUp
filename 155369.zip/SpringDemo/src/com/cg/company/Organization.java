package com.cg.company;

public class Organization {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Organization [name=" + name + "]";
	}

	public Organization() {
		System.out.println("obj getting created");
	}
	
}
