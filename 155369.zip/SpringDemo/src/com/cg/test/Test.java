package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.company.Organization;
import com.cg.renderer.MessageRenderer;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
	/*	MessageRenderer renderer = (MessageRenderer) context.getBean("renderer");*/
		/*renderer.render();*/
		Organization org = (Organization) context.getBean("org");
		org.setName("ACC");
		System.out.println(org.hashCode() + " " + org.getName());
		
		org = (Organization) context.getBean("org");
		
		System.out.println(org.hashCode() + " " + org.getName());
		
		Organization org1 = (Organization) context.getBean("org");
		org1.setName("ACC");
		System.out.println(org1.hashCode() + " " + org1.getName());
		
		Organization org2 = (Organization) context.getBean("org");
		org2.setName("CG");
		System.out.println(org2.hashCode() + " " + org2.getName());
	}
}
