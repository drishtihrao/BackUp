package in.co.cg.calc.test;

import static org.junit.Assert.*;

import org.junit.Test;

import in.co.cg.calc.Maths;
import junit.framework.Assert;

public class MultiplicationTest {

	@Test
	public void testMultTwoPositive() {
		Maths maths = new Maths();
		int ans = maths.multiply(2,3);
		Assert.assertEquals(6, ans);
	}
	
	@Test
	public void testMultTwoNegative() {
		Maths maths = new Maths();
		int ans = maths.multiply(-2,-3);
		Assert.assertEquals(6, ans);
	}
	
	@Test
	public void testMultTwoZero() {
		Maths maths = new Maths();
		int ans = maths.multiply(0,0);
		Assert.assertEquals(0, ans);
	}
	
	@Test
	public void testMultOneZeroOneNonZero() {
		Maths maths = new Maths();
		int ans = maths.multiply(2,0);
		Assert.assertEquals(0, ans);
	}

	@Test
	public void testMultOnePositiveOneNegative() {
		Maths maths = new Maths();
		int ans = maths.multiply(2,-7);
		Assert.assertEquals(-14, ans);
	}
}
