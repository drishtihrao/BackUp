package com.cg.testparkedcars;

import java.util.Set;
import java.util.TreeSet;

import com.cg.parkedcarcollections.Parked_CarOwner_Details;

public class TestParkedCar {

	public static void main(String[] args) {
		
		Set<Parked_CarOwner_Details> carList = new TreeSet<>();
		
		Parked_CarOwner_Details honda = new Parked_CarOwner_Details("Honda", "City", "MH 02 4500", 9800210, "D-6,MG Road, Mumbai");
		Parked_CarOwner_Details mercedes = new Parked_CarOwner_Details("Mercedes", "M", "MH 02 666", 900010, "7-12, Sampada, Chembur, Mumbai");
		Parked_CarOwner_Details lamborgini = new Parked_CarOwner_Details("Lamborgini", "Matte", "MH 02 7895", 87945210, "Nariman Point, Mumbai");
		
		carList.add(honda);
		carList.add(mercedes);
		carList.add(lamborgini);
		
		carList.stream().forEach(System.out::println);
	}

}
