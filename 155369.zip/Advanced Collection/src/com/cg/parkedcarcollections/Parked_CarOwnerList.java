package com.cg.parkedcarcollections;

import java.util.Set;
import java.util.TreeSet;

public class Parked_CarOwnerList {
	int token = 1, floor = 1, section =1, flag=0;
	
	Set<Parked_CarOwner_Details> car = new TreeSet<>();
	
	public void add_new_car(Parked_CarOwner_Details pcd) {
		car.add(pcd);	
		pcd.setToken(token);
		token++;
		if(token>20) {
			section++;
			if(section>4)
				floor++;
		}
	}
	
	public void remove_car(Parked_CarOwner_Details pcd) {
		car.remove(pcd);	
	}
	
	public int get_parked_car_location(Parked_CarOwner_Details pcd) {
		return pcd.getToken();
	}

	@Override
	public String toString() {
		return "Parked_CarOwnerList [token=" + token + ", floor=" + floor + ", section=" + section + ", flag=" + flag
				+ ", car=" + car + "]";
	}
	
	
}
