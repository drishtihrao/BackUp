package com.cg.parkedcarcollections;

public class Parked_CarOwner_Details {
	private String ownerName;
	private String carModel;
	private String carNumber;
	private long ownerMobNumber;
	private String ownerAddress;
	private int token;
	
	public Parked_CarOwner_Details(String ownerName, String carModel, String carNumber, long ownerMobNumber,
			String ownerAddress) {
		this.ownerName = ownerName;
		this.carModel = carModel;
		this.carNumber = carNumber;
		this.ownerMobNumber = ownerMobNumber;
		this.ownerAddress = ownerAddress;
		
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public long getOwnerMobNumber() {
		return ownerMobNumber;
	}

	public void setOwnerMobNumber(long ownerMobNumber) {
		this.ownerMobNumber = ownerMobNumber;
	}

	public String getOwnerAddress() {
		return ownerAddress;
	}

	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}

	public int getToken() {
		return token;
	}

	public void setToken(int token) {
		this.token = token;
	}
	
	
	
	
	
	
	
}
