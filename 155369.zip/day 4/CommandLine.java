//giving commands using command line argumets
public class CommandLine {
	public static void main(String[] args) {
		System.out.println("Sum of 3 numbers is "+(Integer.parseInt(args[0])+Integer.parseInt(args[1])+Integer.parseInt(args[2])) );
	}
}