package TestEmp;
import Test.Emp;
import Pack2.Org;
 public class Employee{
	 public static void main(String args[]) {
		 Emp.getEmpId();
		 Org.display();
	 }
 }


