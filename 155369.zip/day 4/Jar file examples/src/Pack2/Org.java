package Pack2;

public class Org {
	public static void display() {
		System.out.println("org");
	}

}
