package Test;

public class Emp {
	static int empId = 192;
	public static void getEmpId() {
		System.out.println("The emp id is " + empId);
	}

}
