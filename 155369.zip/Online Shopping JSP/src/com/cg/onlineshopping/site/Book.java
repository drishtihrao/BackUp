package com.cg.onlineshopping.site;

public class Book {
	private String bookName;
	private int bookCount = 0;
	

//	public Collection<Book> displayAllBooks(){
//		return book.values();
//	}
	
	

	public String getBookName() {
		return bookName;
	}

	public Book(String bookName, int bookCount) {
	super();
	this.bookName = bookName;
	this.bookCount = bookCount;
}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getCount() {
		return bookCount;
	}
	

	public void setCount(int count) {
		this.bookCount = count;
	}

	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", count=" + bookCount + "]";
	}

}
