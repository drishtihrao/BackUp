package com.cg.onlineshopping.site;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("*.app")
public class ShopStop extends HttpServlet {

	private Cart cart = new Cart();

	public ShopStop() {

	}
	
	Map<String, Book> bookList = new HashMap<>();
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		HttpSession session = request.getSession();
		System.out.println(action);

		switch (action) {
		case "/addnew.app":
			int bookCount = Integer.parseInt(request.getParameter("bookCount"));
			String bookName = request.getParameter("bookName");
			Book book = new Book(bookName, bookCount);
			bookList.put(bookName, book);
			response.sendRedirect("viewall.app");
			break;

			
		case "/viewall.app":
			
			Collection<Book> books = cart.displayCart();
			request.setAttribute("books", books);
			RequestDispatcher dispatcher = request.getRequestDispatcher("viewAll.jsp");
			dispatcher.forward(request, response);
			break;
			
		case "/delete.app":
			bookCount = Integer.parseInt(request.getParameter("bookCount"));
			--bookCount;
			bookName = request.getParameter("bookName");

			book = new Book(bookName, bookCount);
			cart.removeFromCart(book);
			response.sendRedirect("viewall.app");
			break;
			
			
		default:
			
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	
	
	
//	int bookCount = Integer.parseInt(request.getParameter("bookCount"));
//	++bookCount;
//	response.sendRedirect("save.app");
	
//	bookCount = Integer.parseInt(request.getParameter("bookCount"));
//	String bookName = request.getParameter("bookName");
//
//	Book book = new Book(bookName, bookCount);
//	cart.addBook(book);
//	response.sendRedirect("viewall.app");
	
	
	
}
