package com.cg.onlineshopping.site;

import java.util.ArrayList;

public class Cart {
	private static ArrayList<Book> items;
	
	public void shoppingcart() {
		items=new ArrayList<Book>();
	}
	
	public void addBook(Book book) {
		items.add(book);
	}
	
	public void removeFromCart(Book book) {
		items.remove(book);
	}
	
	public int getSize() {
		return items.size();
	}
	
	public ArrayList<Book> displayCart(){
		return items;
	}
	
	public void bookCount() {
		
	}
}
