package com.streamexamples;

import java.util.function.Predicate;

public class PerformStreamOperations {
	public  static Predicate<Integer> isOdd(){
		Predicate<Integer> predicate = element -> ((element % 2) != 0)? true : false;
		return predicate;
	}
	public  static Predicate<Integer> isEven(){
		Predicate<Integer> predicate = element -> ((element % 2) == 0)? true : false;
		return predicate;
	}
	public  static Predicate<Integer> isPalindrome(){
		Predicate<Integer> predicate = element -> (Integer.toString(element)).equals(new StringBuilder(Integer.toString(element)).reverse().toString());
		return predicate;
	}
}
