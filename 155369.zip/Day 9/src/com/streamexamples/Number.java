package com.streamexamples;

interface Number{
	boolean state(int n);
}



//public class Number {
//	int number;
//	public Number (int num) {
//	this.number = num;
//	}
//	
//	public boolean isOdd() {
//		boolean state = false;
//		if((number % 2) == 0) {
//			state = true;
//		}
//		return state;
//	}
//}
