//package com.streamexamples;
//
//import java.util.Scanner;
//import java.util.function.Predicate;
//
//public class OddNumFinder {
//
//	public static void main(String[] args) {
//		Scanner scanner = new Scanner(System.in);
//	
//		System.out.println("Enter a number");
//		Number number;
//		number -> ((number%2)!=0);
//		
////		int num = scanner.nextInt();
//		
//		Predicate<Integer> isOddNumber = num -> ((num%2)==0);
//			
//		}
//
//	}
//
//}
