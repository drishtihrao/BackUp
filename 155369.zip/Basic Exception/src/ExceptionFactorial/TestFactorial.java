package ExceptionFactorial;

public class TestFactorial {
	public static void main(String args[]) {
		Factorial fact = new Factorial();
		try {
		int ans = fact.getFactorial(32);
		System.out.println("factorial = " + ans);
		}
		catch (InvalidInputException e){
			e.printStackTrace();
		}
		catch (FactorialException e){
			e.printStackTrace();
		}
		catch (Exception e){
			e.printStackTrace();
		}
		
	}	
}
