package ExceptionFactorial;

class InvalidInputException extends Exception{
	public InvalidInputException(String message) {
		super(message);
	}
}

class FactorialException extends Exception{
	public FactorialException(String message) {
		super(message);
	}
}

public class Factorial {
	long factorial = 1;
	int getFactorial(int num) throws InvalidInputException, FactorialException {
		if(num < 2) {
			throw new InvalidInputException("Enter a number greater than two");
		}
		for(int i = 1; i<num+1 ; i++) {
				factorial = factorial*i;
		}
		if(factorial > 2147483647) {
			throw new FactorialException("Enter a smaller number");
		}
		return (int)factorial;
	}
}
