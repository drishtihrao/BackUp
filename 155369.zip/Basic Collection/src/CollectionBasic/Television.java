package CollectionBasic;

//declaring the variable in Television class
public class Television {
	String company;
	String type;
	boolean threeDEnabled;
	double price;
	
	//creating a constructor for Television class
	Television(String comp, String type, boolean threeD, double price){
		this.company = comp;
		this.type = type;
		this.threeDEnabled = threeD;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Television with company = " + company + ", type = " + type + ", threeDEnabled = " + threeDEnabled + ", price = "
				+ price + ".";
	}
	
	

}
