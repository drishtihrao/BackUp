package CollectionBasic;
import java.util.LinkedHashSet;
import java.util.Set;

public class testSet {
	public static void main(String args[]) {
		Set set = new LinkedHashSet();
		
		set.add(new CellPhone("Samsung", "X10", "Black", "Android", 14000));
		set.add(new CellPhone("OnePlus", "6", "Red", "Android", 19000));
		set.add(new CellPhone("Apple", "X", "Matte", "iOS", 34000));
		set.add(new Laptop("Acer", "Lfive", "Windows", "i5"));
		set.add(new Laptop("Dell", "Lthree", "MacOS", "i8"));
		set.add(new Laptop("HP", "Lseven", "Linux", "i7"));
		set.add(new Car("Mercedes", "820", 2008, 23000));
		set.add(new Car("BMW", "827", 2014, 70000));
		set.add(new Car("Lamborgini", "X", 2015, 2023000));
		set.add(new Television("LG", "LCD", true, 20000));
		set.add(new Television("Onida", "LED", true, 23000));
		set.add(new Television("Sony", "Plasma", false, 25000));
		set.add(new School("Vivek", "Mumbai", "Mumbai", 20));
		set.add(new School("SFIT", "Mumbai", "Bov", 200));
		set.add(new School("Patkar", "Boisar", "Palghar", 12));
		
		set.stream().forEach((linkedHash) -> System.out.println(linkedHash));

	}
}