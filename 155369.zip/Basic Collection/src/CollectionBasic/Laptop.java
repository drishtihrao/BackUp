package CollectionBasic;

//creating a class laptop and declaring the variables
public class Laptop {
	String companyName;
	String model;
	String operatingSystem;
	String processor;
	
	//creating a constructor for Laptop class
	Laptop(String name, String model, String os, String processor){
		this.companyName = name;
		this.model = model;
		this.operatingSystem = os;
		this.processor = processor;
	}

	@Override
	public String toString() {
		return "Laptop with companyName = " + companyName + ", model = " + model + ", operatingSystem = " + operatingSystem
				+ ", processor = " + processor + ".";
	}
	
	
}
