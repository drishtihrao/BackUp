package CollectionBasic;
import java.util.List;
import java.util.LinkedList;

public class testList {
	public static void main(String args[]) {
		List list = new LinkedList();
		
		list.add(new CellPhone("Samsung", "X10", "Black", "Android", 14000));
		list.add(new CellPhone("OnePlus", "6", "Red", "Android", 19000));
		list.add(new CellPhone("Apple", "X", "Matte", "iOS", 34000));
		list.add(new Laptop("Acer", "Lfive", "Windows", "i5"));
		list.add(new Laptop("Dell", "Lthree", "MacOS", "i8"));
		list.add(new Laptop("HP", "Lseven", "Linux", "i7"));
		list.add(new Car("Mercedes", "820", 2008, 23000));
		list.add(new Car("BMW", "827", 2014, 70000));
		list.add(new Car("Lamborgini", "X", 2015, 2023000));
		list.add(new Television("LG", "LCD", true, 20000));
		list.add(new Television("Onida", "LED", true, 23000));
		list.add(new Television("Sony", "Plasma", false, 25000));
		list.add(new School("Vivek", "Mumbai", "Mumbai", 20));
		list.add(new School("SFIT", "Mumbai", "Bov", 200));
		list.add(new School("Patkar", "Boisar", "Palghar", 12));
		
		list.stream().forEach((list_linked) -> System.out.println(list_linked));

	}
}
