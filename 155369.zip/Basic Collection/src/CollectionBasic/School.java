package CollectionBasic;

public class School {
	String name;
	String city;
	String schoolDistrict;
	int greatSchoolRanking;
	
	//creating a constructor for School class
	School(String name, String city, String dist, int rank){
		this.name = name;
		this.city = city;
		this.schoolDistrict = dist;
		this.greatSchoolRanking = rank;
	}

	@Override
	public String toString() {
		return "School with name = " + name + ", city = " + city + ", schoolDistrict = " + schoolDistrict
				+ ", greatSchoolRanking = " + greatSchoolRanking + ".";
	}
	

}
